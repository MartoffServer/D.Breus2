nopCommerce version: 

Steps to reproduce the problem: 
