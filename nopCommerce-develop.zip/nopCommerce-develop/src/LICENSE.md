﻿nopCommerce Public License Version 3.0 ("NPL")


nopCommerce open source edition is licensed under nopCommerce Public License. It's basically a GPLv3 License plus the "powered by nopCommerce" text requirement on every single page. The nopCommerce Public License Version 3.0 ("NPL") consists of the GPL3 License with the Additional Terms below. The original GPLv3 License can be found at: http://opensource.org/licenses/GPL-3.0

Additional nopCommerce terms:

However, in addition to the other notice obligations, (1) all copies of the Program in Executable and Source Code form must, as a form of attribution of the original author, include on each user interface screen (i) the "powered by nopCommerce" text; and (2) all derivative works and copies of derivative works of the Covered Code in Executable and Source Code form must include on each user interface screen (i) the "powered by nopCommerce" text. In addition, the "powered by nopCommerce" text, as appropriate, must be visible to all users, must appear in each user interface screen, and must be in the same position. When users click on the "powered by nopCommerce" text it must direct them to http://www.nopCommerce.com. This obligation shall also apply to any copies or derivative works. Find more info at http://www.nopcommerce.com/p/1/nopcommerce-copyright-removal-key.aspx


License page: http://www.nopcommerce.com/licensev3.aspx