﻿namespace Nop.Core.Domain.Catalog
{
    public partial class ProductTagWithCount
    {
        public int ProductTagId { get; set; }

        public int ProductCount { get; set; }
    }
}